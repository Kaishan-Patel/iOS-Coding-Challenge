//
//  TableViewController.swift
//  iOS1
//
//  Created by Kaishan Patel on 21/09/2018.
//  Copyright © 2018 Kaishan Patel. All rights reserved.
//

import UIKit

class TableViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    var tableViewDataSource = [NewInfo]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableViewDataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! LeagueTableViewCell
        
        //cell.teamName?.text = tableViewDataSource[indexPath.row].teamName
        
        return cell
    }
    
    @IBAction func refreshButton(_ sender: Any) {
        let url = URL(string: "http://api.football-data.org/v2/competitions/PL/standings")
        var request = URLRequest(url: url!)
        request.setValue("API KEY", forHTTPHeaderField: "X-Auth-Token")
        request.httpMethod = "GET"
        parseData(fullURL: url!)
    }
    
    func parseData(fullURL: URL) {
        var myNews = NewInfo()
        //let teams = tableViewDataSource?.id
        
        let task = URLSession.shared.dataTask(with: fullURL) { (data, response, error) in
            
            if error != nil
            {
                print("Error")
            }
            else
            {
                do
                {
                    if let content = data
                    {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: .mutableContainers)
                        print(myJson)
                        
                        if let jsonData = myJson as? [String : Any]
                        {
                                if let myResults = jsonData["standings"] as? [[String : Any]]
                                {
                                    for standings in myResults
                                    {
                                        if let position = standings["table"] as? [String : Any]
                                        {
                                            if let t = position["position"] as? Int
                                            {
                                                myNews.position = t
                                            }
                                        }
                                } // end of loop
                                dump(self.tableViewDataSource)
                                
                            }
                        }
                    }
                }
                catch
                {
                    
                }
            }
        }
        task.resume()
    } // end function
    
}
