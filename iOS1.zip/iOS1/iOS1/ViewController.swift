//
//  ViewController.swift
//  iOS1
//
//  Created by Kaishan Patel on 21/09/2018.
//  Copyright © 2018 Kaishan Patel. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var myTableView: UITableView!
    
    var tableViewDataSource = [NewInfo]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.parseData()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableViewDataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = myTableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell
        cell.homeLabel?.text = tableViewDataSource[indexPath.row].homeTeam
        cell.awayLabel?.text = tableViewDataSource[indexPath.row].awayTeam
        cell.utcDateLabel?.text = tableViewDataSource[indexPath.row].utcDate
        
        return cell
    }
    
    func parseData() {
        var myNews = NewInfo()
        let url = "https://api.football-data.org/v2/competitions/PL/matches?matchday=6"
        var request = URLRequest(url: URL(string: url)!)
        request.setValue("API KEY", forHTTPHeaderField: "X-Auth-Token")
        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            if error != nil
            {
                print("Error")
            }
            else
            {
                do
                {
                    if let content = data
                    {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: .mutableContainers)
                       print(myJson)
                        
                        if let jsonData = myJson as? [String : Any]
                        {
                            if let myResults = jsonData["matches"] as? [[String : Any]]
                            {
                                for match in myResults
                                {
                                    if let homeTeam = match["homeTeam"] as? [String : Any]
                                    {
                                        if let id = homeTeam["id"] as? Int
                                        {
                                            myNews.homeId = id
                                        }
                                    }
                                    if let home = match["homeTeam"] as? [String : Any]
                                    {
                                        if let homeName = home["name"] as? String
                                        {
                                        myNews.homeTeam = homeName
                                        }
                                    }
                                    if let homeTeam = match["awayTeam"] as? [String : Any]
                                    {
                                        if let id = homeTeam["id"] as? Int
                                        {
                                            myNews.awayId = id
                                        }
                                    }
                                    if let away = match["awayTeam"] as? [String : Any]
                                    {
                                        if let awayName = away["name"] as? String
                                        {
                                            myNews.awayTeam = awayName
                                        }
                                    }
                                    if let utc = match["utcDate"] as? String
                                    {
                                        myNews.utcDate = utc
                                    }
                                    self.tableViewDataSource.append(myNews)
                                } // end of loop
                                dump(self.tableViewDataSource)
                                DispatchQueue.main.async {
                                    self.myTableView.reloadData()
                                }
                            }
                        }
                    }
                }
                catch
                {
                    
                }
            }
        }
        task.resume()
    } // end function
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let cell = sender as? UITableViewCell {
            let i = myTableView.indexPath(for: cell)!.row
            if segue.identifier == "details" { // get segue identifier from name 'details'
                let dvc = segue.destination as! MatchViewController // Swift file the program will go to
                dvc.tableViewDataSource = self.tableViewDataSource[i]
            }
        }
    }
} // end class
