//
//  Model.swift
//  iOS1
//
//  Created by Kaishan Patel on 21/09/2018.
//  Copyright © 2018 Kaishan Patel. All rights reserved.
//

import Foundation

struct NewInfo
{
    var homeId:Int = 0
    var awayId: Int = 0
    var homeTeam:String = ""
    var awayTeam:String = ""
    var utcDate:String = ""
    var address:String = ""
    var position:Int = 0
    var teamName:String = ""
}

struct MoreInfo
{
    var address:String = ""
}
