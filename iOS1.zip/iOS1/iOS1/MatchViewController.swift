//
//  MatchViewController.swift
//  iOS1
//
//  Created by Kaishan Patel on 21/09/2018.
//  Copyright © 2018 Kaishan Patel. All rights reserved.
//

import UIKit

class MatchViewController: UIViewController {

    @IBOutlet weak var awayLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var homeTeamImg: UIImageView!
    @IBOutlet weak var awayTeamImg: UIImageView!
    @IBOutlet weak var homeAddress: UILabel!
    
    var tableViewDataSource: NewInfo?
    var tableViewDataSource1 = [MoreInfo]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //self.parseData()
        nameLabel.text = tableViewDataSource?.homeTeam
        awayLabel.text = tableViewDataSource?.awayTeam
        let selectIMG = tableViewDataSource?.homeTeam
        homeTeamImg.image = UIImage(named: selectIMG!)
        let selectIMG1 = tableViewDataSource?.awayTeam
        awayTeamImg.image = UIImage(named: selectIMG1!)
        
    }
    @IBAction func btn(_ sender: Any) {
        let teams = tableViewDataSource?.homeId
        let url = URL(string: "https://api.football-data.org/v2/teams/\(teams!)")
        var request = URLRequest(url: url!)
        request.setValue("API KEY", forHTTPHeaderField: "X-Auth-Token")
        request.httpMethod = "GET"
        parseData(fullURL: url!)
        homeAddress.text = tableViewDataSource?.address
    }
    
    func parseData(fullURL: URL) {
        var myNews = NewInfo()
        //let teams = tableViewDataSource?.id
        
        let task = URLSession.shared.dataTask(with: fullURL) { (data, response, error) in
            
            if error != nil
            {
                print("Error")
            }
            else
            {
                do
                {
                    if let content = data
                    {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: .mutableContainers)
                        print(myJson)
                        
                        if let jsonData = myJson as? [String : Any]
                        {
                            if let myResults = jsonData["teams"] as? [[String : Any]]
                            {
                                for team in myResults
                                {
                                    if let addresss = team["address"] as? String
                                    {
                                        myNews.address = addresss
                                    }
                                } // end of loop
                                dump(self.tableViewDataSource)
                                
                            }
                        }
                    }
                }
                catch
                {
                    
                }
            }
        }
        task.resume()
    } // end function
    
}

